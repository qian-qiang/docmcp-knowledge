@echo off
chcp 65001 >nul
title Reguverse Assistant CN - Uninstaller
echo ============================================
echo  Uninstalling: Reguverse Assistant CN
echo ============================================
echo.

set "ADDIN_ID=84cda2d3-23bb-4fea-b68f-42c103bb995f"
set "MANIFEST_DIR=%LOCALAPPDATA%\ReguverseAssistant\reguverse-assistant-cn"
set "REG_KEY=HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"

echo [1/4] Removing add-in registration...
reg delete "%REG_KEY%" /v "%ADDIN_ID%" /f >nul 2>&1

echo [2/4] Removing manifest directory...
if exist "%MANIFEST_DIR%" rd /s /q "%MANIFEST_DIR%" >nul 2>&1

echo [3/4] Clearing Office Add-in cache...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" (
    rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" >nul 2>&1
)
for /d %%F in ("%LOCALAPPDATA%\Packages\Microsoft.Win32WebViewHost_*") do (
    if exist "%%F\AC" rd /s /q "%%F\AC" >nul 2>&1
)

echo [4/4] Done!

echo.
echo ============================================
echo  Uninstall complete.
echo  Please close ALL Word windows and re-open.
echo ============================================
echo.
pause
