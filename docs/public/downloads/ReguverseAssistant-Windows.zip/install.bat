@echo off
chcp 65001 >nul
title Reguverse Assistant - Installer
echo ============================================
echo  Installing: Reguverse Assistant
echo ============================================
echo.

set "ADDIN_ID=84cda2d3-23bb-4fea-b68f-42c103bb995c"
set "MANIFEST_DIR=%LOCALAPPDATA%\ReguverseAssistant\reguverse-assistant"
set "REG_KEY=HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"
set "CACHE_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions"

echo [1/5] Clearing Office Add-in cache...
if exist "%CACHE_DIR%" rd /s /q "%CACHE_DIR%" >nul 2>&1
for /d %%F in ("%LOCALAPPDATA%\Packages\Microsoft.Win32WebViewHost_*") do (
    if exist "%%F\AC" rd /s /q "%%F\AC" >nul 2>&1
)

echo [2/5] Creating manifest directory...
if not exist "%MANIFEST_DIR%" mkdir "%MANIFEST_DIR%"

echo [3/5] Copying manifest file...
copy /Y "%~dp0manifest.xml" "%MANIFEST_DIR%\manifest.xml" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy manifest file.
    pause
    exit /b 1
)

echo [4/5] Registering add-in in Developer settings...
reg add "%REG_KEY%" /v "%ADDIN_ID%" /t REG_SZ /d "%MANIFEST_DIR%\manifest.xml" /f >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Failed to write registry entry.
    pause
    exit /b 1
)

echo [5/5] Done!

echo.
echo ============================================
echo  Installation complete!
echo.
echo  Close ALL Word windows, then re-open Word.
echo  The add-in will appear in:
echo    Home ^> Add-ins ^> MY ADD-INS
echo.
echo  Look for: Reguverse Assistant
echo ============================================
echo.
pause
